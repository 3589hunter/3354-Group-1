import React from "react";
import { Task } from "@shared/schema";
import TaskItem from "./TaskItem";
import { cn } from "@/lib/utils";
import { ListTodo, CalendarDays } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface TaskListProps {
  title: string;
  icon?: "list" | "calendar";
  tasks?: Task[];
  isLoading?: boolean;
  className?: string;
  emptyMessage?: string;
  showViewAll?: boolean;
  onViewAll?: () => void;
}

export default function TaskList({
  title,
  icon = "list",
  tasks,
  isLoading = false,
  className,
  emptyMessage = "No tasks available",
  showViewAll = false,
  onViewAll,
}: TaskListProps) {
  const icons = {
    list: <ListTodo className="h-4 w-4 text-primary mr-2" />,
    calendar: <CalendarDays className="h-4 w-4 text-primary mr-2" />,
  };

  return (
    <section className={cn("px-4 mb-4", className)}>
      <div className="flex items-center justify-between mb-2">
        <h2 className="font-medium flex items-center">
          {icons[icon]}
          {title}
        </h2>
        
        {showViewAll && (
          <button 
            className="text-sm text-primary"
            onClick={onViewAll}
          >
            See all
          </button>
        )}
      </div>
      
      <div className="space-y-2">
        {isLoading ? (
          // Loading skeletons
          <>
            <Skeleton className="h-16 w-full rounded-lg" />
            <Skeleton className="h-16 w-full rounded-lg" />
            <Skeleton className="h-16 w-full rounded-lg" />
          </>
        ) : tasks && tasks.length > 0 ? (
          // Task list
          tasks.map((task) => (
            <TaskItem key={task.id} task={task} />
          ))
        ) : (
          // Empty state
          <div className="bg-secondary/30 rounded-lg p-4 text-center text-muted-foreground">
            {emptyMessage}
          </div>
        )}
      </div>
    </section>
  );
}
