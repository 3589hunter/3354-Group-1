import React from "react";
import { Task } from "@shared/schema";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { Clock, MoreVertical, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface TaskItemProps {
  task: Task;
  onComplete?: () => void;
}

export default function TaskItem({ task, onComplete }: TaskItemProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();

  const formatDueDate = (date: Date | string) => {
    const dueDate = new Date(date);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Check if date is today
    if (
      dueDate.getDate() === today.getDate() &&
      dueDate.getMonth() === today.getMonth() &&
      dueDate.getFullYear() === today.getFullYear()
    ) {
      return `Today at ${format(dueDate, "h:mm a")}`;
    }

    // Check if date is tomorrow
    if (
      dueDate.getDate() === tomorrow.getDate() &&
      dueDate.getMonth() === tomorrow.getMonth() &&
      dueDate.getFullYear() === tomorrow.getFullYear()
    ) {
      return `Tomorrow at ${format(dueDate, "h:mm a")}`;
    }

    // Otherwise return the date formatted as "MMM d"
    return format(dueDate, "MMM d • h:mm a");
  };

  const completeTaskMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/tasks/${task.id}/complete`);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Task completed",
        description: `You earned ${task.expectedDuration} points!`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/upcoming"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/today"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      if (onComplete) onComplete();
    },
    onError: (error: Error) => {
      toast({
        title: "Could not complete task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/tasks/${task.id}`);
    },
    onSuccess: () => {
      toast({
        title: "Task deleted",
        description: "The task has been deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/upcoming"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/today"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Could not delete task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleViewDetails = () => {
    navigate(`/task/${task.id}`);
  };

  const handleCompleteTask = (e: React.MouseEvent) => {
    e.stopPropagation();
    completeTaskMutation.mutate();
  };

  const handleEditTask = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/task/${task.id}?edit=true`);
  };

  const handleDeleteTask = (e: React.MouseEvent) => {
    e.stopPropagation();
    deleteTaskMutation.mutate();
  };

  return (
    <div 
      className="bg-secondary/30 hover:bg-secondary/40 transition-colors rounded-lg p-3 cursor-pointer"
      onClick={handleViewDetails}
    >
      <div className="flex items-start">
        <Button
          variant="ghost"
          size="icon"
          className={cn(
            "w-5 h-5 rounded-full flex-shrink-0 mt-0.5 p-0",
            task.completed 
              ? "bg-primary text-primary-foreground" 
              : "border-2 border-primary hover:border-primary/80"
          )}
          onClick={handleCompleteTask}
          disabled={task.completed || completeTaskMutation.isPending}
        >
          {task.completed && <Check className="h-3 w-3" />}
        </Button>
        
        <div className="ml-3 flex-1">
          <div className="flex justify-between">
            <h3 className={cn(
              "font-medium",
              task.completed && "line-through text-muted-foreground"
            )}>
              {task.title}
            </h3>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground"
                  onClick={(e) => e.stopPropagation()}
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {!task.completed && (
                  <DropdownMenuItem onClick={handleEditTask}>
                    Edit task
                  </DropdownMenuItem>
                )}
                {!task.completed && (
                  <DropdownMenuItem onClick={handleCompleteTask}>
                    Mark as completed
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem 
                  className="text-destructive focus:text-destructive"
                  onClick={handleDeleteTask}
                >
                  Delete task
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          <div className="flex items-center text-muted-foreground text-xs mt-1">
            <Clock className="h-3 w-3 mr-1" />
            {task.completed ? (
              <span>Completed • {task.expectedDuration} min • +{task.pointsAwarded} pts</span>
            ) : (
              <span>Due: {formatDueDate(task.dueDate)} • {task.expectedDuration} min</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
