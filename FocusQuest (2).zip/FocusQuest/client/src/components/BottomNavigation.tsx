import React from "react";
import { cn } from "@/lib/utils";
import { Home, ListTodo, Plus, Bot, User } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";

interface BottomNavigationProps {
  className?: string;
}

export default function BottomNavigation({ className }: BottomNavigationProps) {
  const [location, navigate] = useLocation();

  // Check if current location matches the path
  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <nav className={cn(
      "bg-secondary/50 backdrop-blur-md border-t border-border fixed bottom-0 left-0 right-0 z-10",
      className
    )}>
      <div className="max-w-md mx-auto px-6">
        <div className="flex justify-between">
          <Button
            variant="ghost"
            className={cn(
              "py-3 flex flex-col items-center w-16",
              isActive("/") ? "text-primary" : "text-muted-foreground"
            )}
            onClick={() => navigate("/")}
          >
            <Home className="h-5 w-5" />
            <span className="text-xs mt-1">Home</span>
          </Button>
          
          <Button
            variant="ghost"
            className={cn(
              "py-3 flex flex-col items-center w-16",
              isActive("/tasks") ? "text-primary" : "text-muted-foreground"
            )}
            onClick={() => navigate("/tasks")}
          >
            <ListTodo className="h-5 w-5" />
            <span className="text-xs mt-1">Tasks</span>
          </Button>
          
          <Button
            variant="ghost"
            className="py-3 flex flex-col items-center w-16 text-muted-foreground relative"
            onClick={() => navigate("/new-task")}
          >
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center absolute -top-6">
              <Plus className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xs mt-7">Add</span>
          </Button>
          
          <Button
            variant="ghost"
            className={cn(
              "py-3 flex flex-col items-center w-16",
              isActive("/ai") ? "text-primary" : "text-muted-foreground"
            )}
            onClick={() => navigate("/ai")}
          >
            <Bot className="h-5 w-5" />
            <span className="text-xs mt-1">AI Chat</span>
          </Button>
          
          <Button
            variant="ghost"
            className={cn(
              "py-3 flex flex-col items-center w-16",
              isActive("/profile") ? "text-primary" : "text-muted-foreground"
            )}
            onClick={() => navigate("/profile")}
          >
            <User className="h-5 w-5" />
            <span className="text-xs mt-1">Profile</span>
          </Button>
        </div>
      </div>
    </nav>
  );
}
