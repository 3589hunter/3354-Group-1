import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Timer } from "@/components/ui/timer";
import { Task } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface FocusTimerProps {
  task?: Task;
  initialMinutes?: number;
  className?: string;
}

export default function FocusTimer({ 
  task, 
  initialMinutes = 25, 
  className 
}: FocusTimerProps) {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [focusedMinutes, setFocusedMinutes] = useState(0);
  const [focusedSeconds, setFocusedSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);

  // Start focus session
  const startSessionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/focus-sessions", {
        taskId: task?.id,
      });
      return await res.json();
    },
    onSuccess: (data) => {
      setSessionId(data.id);
      setIsActive(true);
      toast({
        title: "Focus session started",
        description: task ? `Working on: ${task.title}` : "Focus mode activated",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Could not start focus session",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // End focus session
  const endSessionMutation = useMutation({
    mutationFn: async () => {
      if (!sessionId) return null;
      
      // Calculate total duration in minutes
      const totalMinutes = focusedMinutes + (focusedSeconds > 0 ? 1 : 0);
      const pointsEarned = totalMinutes;
      
      const res = await apiRequest("PUT", `/api/focus-sessions/${sessionId}/end`, {
        duration: totalMinutes,
        pointsEarned
      });
      return await res.json();
    },
    onSuccess: (data) => {
      if (data) {
        toast({
          title: "Focus session completed",
          description: `You earned ${data.pointsEarned} points!`,
        });
        queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
        queryClient.invalidateQueries({ queryKey: ["/api/focus-sessions/user"] });
        if (task) {
          queryClient.invalidateQueries({ queryKey: [`/api/focus-sessions/task/${task.id}`] });
        }
      }
      setSessionId(null);
      setFocusedMinutes(0);
      setFocusedSeconds(0);
      setIsActive(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Could not end focus session",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Handle manual start
  const handleStart = () => {
    if (!isActive) {
      startSessionMutation.mutate();
    }
  };

  // Track time spent focusing
  const handleTimeUpdate = (minutes: number, seconds: number) => {
    setFocusedMinutes(initialMinutes - minutes - 1);
    setFocusedSeconds(60 - seconds);
  };

  // Handle timer completion
  const handleComplete = () => {
    if (sessionId) {
      endSessionMutation.mutate();
    }
  };

  // Clean up on unmount or navigation
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isActive && sessionId) {
        e.preventDefault();
        e.returnValue = "You have an active focus session. Are you sure you want to leave?";
        return e.returnValue;
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
      
      // End the session if it's active and component unmounts
      if (isActive && sessionId) {
        endSessionMutation.mutate();
      }
    };
  }, [isActive, sessionId]);

  return (
    <div className={cn("flex flex-col items-center", className)}>
      <div className="animate-pulse-slow mb-6">
        <div className="w-36 h-36 rounded-full bg-secondary/30 border-4 border-primary flex items-center justify-center">
          <Timer
            initialMinutes={initialMinutes}
            initialSeconds={0}
            onComplete={handleComplete}
            onTimeUpdate={handleTimeUpdate}
            autoStart={isActive}
            size="lg"
          />
        </div>
      </div>
      
      {!isActive && (
        <button
          className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium px-6 py-2 rounded-full transition-colors"
          onClick={handleStart}
          disabled={startSessionMutation.isPending}
        >
          Start Focus Session
        </button>
      )}
    </div>
  );
}
