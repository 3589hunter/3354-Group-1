import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Play, Pause, RotateCcw, Forward } from "lucide-react";

interface TimerProps {
  initialMinutes?: number;
  initialSeconds?: number;
  onComplete?: () => void;
  onTimeUpdate?: (minutes: number, seconds: number) => void;
  className?: string;
  autoStart?: boolean;
  size?: "sm" | "md" | "lg";
}

export function Timer({
  initialMinutes = 25,
  initialSeconds = 0,
  onComplete,
  onTimeUpdate,
  className,
  autoStart = false,
  size = "md",
}: TimerProps) {
  const [minutes, setMinutes] = useState(initialMinutes);
  const [seconds, setSeconds] = useState(initialSeconds);
  const [isActive, setIsActive] = useState(autoStart);
  const [isPaused, setIsPaused] = useState(!autoStart);
  const countRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isActive && !isPaused) {
      countRef.current = setInterval(() => {
        if (seconds === 0) {
          if (minutes === 0) {
            clearInterval(countRef.current!);
            setIsActive(false);
            onComplete && onComplete();
            return;
          }
          setMinutes((prevMinutes) => prevMinutes - 1);
          setSeconds(59);
        } else {
          setSeconds((prevSeconds) => prevSeconds - 1);
        }
        
        // Call onTimeUpdate if provided
        if (onTimeUpdate) {
          if (seconds === 0) {
            onTimeUpdate(minutes - 1, 59);
          } else {
            onTimeUpdate(minutes, seconds - 1);
          }
        }
      }, 1000);
    }

    return () => {
      if (countRef.current) {
        clearInterval(countRef.current);
      }
    };
  }, [isActive, isPaused, minutes, seconds, onComplete, onTimeUpdate]);

  const handleStart = () => {
    setIsActive(true);
    setIsPaused(false);
  };

  const handlePause = () => {
    setIsPaused(true);
  };

  const handleResume = () => {
    setIsPaused(false);
  };

  const handleReset = () => {
    clearInterval(countRef.current!);
    setIsActive(false);
    setIsPaused(true);
    setMinutes(initialMinutes);
    setSeconds(initialSeconds);
  };

  const handleSkip = () => {
    clearInterval(countRef.current!);
    setIsActive(false);
    setMinutes(0);
    setSeconds(0);
    onComplete && onComplete();
  };

  // Format time to always show two digits
  const formatTime = (time: number): string => {
    return time < 10 ? `0${time}` : `${time}`;
  };

  // Size-specific classes
  const sizeClasses = {
    sm: {
      container: "text-xl",
      buttons: "w-8 h-8",
      playButton: "w-10 h-10",
    },
    md: {
      container: "text-3xl",
      buttons: "w-10 h-10",
      playButton: "w-12 h-12",
    },
    lg: {
      container: "text-4xl",
      buttons: "w-12 h-12",
      playButton: "w-16 h-16",
    },
  };

  return (
    <div className={cn("flex flex-col items-center gap-6", className)}>
      <div className={cn("font-bold", sizeClasses[size].container)}>
        {formatTime(minutes)}:{formatTime(seconds)}
      </div>
      
      <div className="flex items-center gap-3">
        <Button 
          variant="outline"
          size="icon"
          className={cn("rounded-full", sizeClasses[size].buttons)}
          onClick={handleReset}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
        
        {isActive && !isPaused ? (
          <Button 
            variant="default"
            size="icon"
            className={cn("rounded-full bg-primary text-primary-foreground", sizeClasses[size].playButton)}
            onClick={handlePause}
          >
            <Pause className="h-6 w-6" />
          </Button>
        ) : (
          <Button 
            variant="default"
            size="icon"
            className={cn("rounded-full bg-primary text-primary-foreground", sizeClasses[size].playButton)}
            onClick={isActive ? handleResume : handleStart}
          >
            <Play className="h-6 w-6 ml-1" />
          </Button>
        )}
        
        <Button 
          variant="outline"
          size="icon"
          className={cn("rounded-full", sizeClasses[size].buttons)}
          onClick={handleSkip}
        >
          <Forward className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
