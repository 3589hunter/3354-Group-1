import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import BottomNavigation from "@/components/BottomNavigation";
import TaskList from "@/components/TaskList";
import { useLocation } from "wouter";
import { Bell, Compass, ArrowUp, Bot, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const [, navigate] = useLocation();

  // Fetch user stats
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/stats"],
  });

  // Fetch upcoming tasks
  const { data: upcomingTasks, isLoading: isLoadingUpcoming } = useQuery({
    queryKey: ["/api/tasks/upcoming"],
  });

  // Fetch today's tasks
  const { data: todayTasks, isLoading: isLoadingToday } = useQuery({
    queryKey: ["/api/tasks/today"],
  });

  // Calculate hours from minutes
  const focusHours = stats?.todayFocusTimeMinutes
    ? (stats.todayFocusTimeMinutes / 60).toFixed(1)
    : 0;

  // Format user initials for avatar
  const getInitials = (username: string) => {
    return username.substring(0, 2).toUpperCase();
  };

  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* Header */}
      <header className="px-4 py-3 flex items-center justify-between border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
            <Compass className="h-4 w-4 text-primary" />
          </div>
          <h1 className="font-semibold">FocusQuest</h1>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button variant="ghost" size="icon" className="rounded-full">
            <Bell className="h-5 w-5 text-muted-foreground" />
          </Button>
          <Avatar>
            <AvatarFallback className="bg-primary text-primary-foreground">
              {user && getInitials(user.username)}
            </AvatarFallback>
          </Avatar>
        </div>
      </header>
      
      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* Stats Overview */}
        <section className="p-4 mb-4">
          <div className="grid grid-cols-2 gap-3">
            <Card>
              <CardContent className="p-3">
                {isLoadingStats ? (
                  <Skeleton className="h-16 w-full" />
                ) : (
                  <>
                    <span className="text-muted-foreground text-xs">Focus Time</span>
                    <div className="flex items-end mt-1">
                      <span className="text-xl font-semibold">{focusHours}</span>
                      <span className="text-muted-foreground text-xs ml-1 mb-0.5">hours today</span>
                    </div>
                    <div className="mt-2">
                      <Progress value={65} className="h-1.5" />
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-3">
                {isLoadingStats ? (
                  <Skeleton className="h-16 w-full" />
                ) : (
                  <>
                    <span className="text-muted-foreground text-xs">Total Points</span>
                    <div className="flex items-end mt-1">
                      <span className="text-xl font-semibold">{stats?.totalPoints || 0}</span>
                      <span className="text-muted-foreground text-xs ml-1 mb-0.5">pts</span>
                    </div>
                    <div className="flex items-center mt-2">
                      <ArrowUp className="h-3 w-3 text-green-500" />
                      <span className="text-green-500 text-xs ml-1">+{stats?.todayPointsEarned || 0} today</span>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </section>
        
        {/* Upcoming Tasks */}
        <TaskList
          title="Upcoming Tasks"
          icon="list"
          tasks={upcomingTasks}
          isLoading={isLoadingUpcoming}
          emptyMessage="No upcoming tasks. Add some tasks to get started!"
          showViewAll={true}
          onViewAll={() => navigate("/tasks")}
        />
        
        {/* AI Insights */}
        <section className="px-4 mb-4">
          <div className="bg-gradient-to-r from-primary/80 to-primary/50 rounded-xl p-4">
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-full bg-background/20 flex items-center justify-center">
                <Bot className="h-5 w-5 text-primary-foreground" />
              </div>
              <div className="ml-3">
                <h3 className="font-medium mb-1">AI Assistant</h3>
                <p className="text-sm text-primary-foreground/90">
                  {stats?.streakDays && stats.streakDays > 0 
                    ? `You're on a ${stats.streakDays}-day streak! Keep it up to build momentum.`
                    : "Ready to boost your productivity? Start a focus session now!"}
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Today's Tasks */}
        <TaskList
          title="Today's Tasks"
          icon="calendar"
          tasks={todayTasks}
          isLoading={isLoadingToday}
          emptyMessage="No tasks for today. Enjoy your day!"
          className="mb-20"
        />
      </main>
      
      {/* Focus Mode Button */}
      <div className="fixed bottom-20 left-0 right-0 flex justify-center z-10">
        <Button 
          className="bg-purple-600 text-white font-medium px-6 py-2 rounded-full shadow-lg flex items-center hover:bg-purple-700"
          variant="default"
          onClick={() => navigate("/focus")}
        >
          <Clock className="mr-2 h-4 w-4" />
          Focus mode
        </Button>
      </div>
      
      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
}
