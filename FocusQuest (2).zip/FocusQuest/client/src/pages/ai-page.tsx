import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import BottomNavigation from "@/components/BottomNavigation";
import { 
  ArrowLeft, 
  Send,
  Bot,
  RefreshCw,
  User,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Card } from "@/components/ui/card";

// Message type for the chat
type Message = {
  id: string;
  sender: "user" | "assistant";
  text: string;
  timestamp: Date;
};

// Sample responses for the AI assistant
const aiResponses = {
  greeting: "👋 Hello! I'm your FocusQuest assistant. I can help you with task management, focus techniques, and productivity tips. What would you like to know today?",
  productivity: "💡 Here are some productivity tips:\n\n1. Break large tasks into smaller, manageable chunks\n2. Use the Pomodoro Technique: 25 minutes of focused work followed by a 5-minute break\n3. Prioritize your most important tasks early in the day\n4. Minimize distractions by silencing notifications\n5. Take regular breaks to maintain mental clarity",
  focus: "🧠 To improve focus, try these techniques:\n\n• Create a dedicated workspace free from distractions\n• Use noise-cancelling headphones or ambient sound\n• Practice mindfulness meditation for 5-10 minutes before starting work\n• Stay hydrated and maintain proper nutrition\n• Get enough sleep (7-8 hours) to ensure optimal cognitive function",
  motivation: "✨ When you're feeling unmotivated, remember:\n\n• Start with just 5 minutes of work - often momentum builds naturally\n• Visualize completing your tasks and the sense of accomplishment\n• Connect your tasks to your bigger goals and values\n• Reward yourself after completing difficult tasks\n• Be kind to yourself - everyone has off days",
  default: "I'm still learning about productivity and focus techniques. Could you ask me something else about task management, focus techniques, or general productivity tips?"
};

// Generate a unique ID for messages
const generateId = () => Math.random().toString(36).substring(2, 9);

export default function AIPage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [showApiKeyPrompt, setShowApiKeyPrompt] = useState(true); // Show API key prompt
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Check if OpenAI integration is working
  const [openAIStatus, setOpenAIStatus] = useState<{enabled: boolean, message: string} | null>(null);
  
  useEffect(() => {
    // Check OpenAI status
    const checkOpenAIStatus = async () => {
      try {
        // Make sure we're authenticated first
        if (!user) return;

        const res = await fetch('/api/ai/status', {
          headers: {
            'Content-Type': 'application/json'
          },
          credentials: 'include' // Important for cookie-based auth
        });
        
        if (res.ok) {
          const data = await res.json();
          console.log("OpenAI status response:", data);
          setOpenAIStatus(data);
          setShowApiKeyPrompt(!data.enabled);
        } else {
          console.error("Failed to get OpenAI status, status:", res.status);
          setShowApiKeyPrompt(true);
        }
      } catch (error) {
        console.error("Failed to check OpenAI status:", error);
        setShowApiKeyPrompt(true);
      }
    };
    
    checkOpenAIStatus();
  }, [user]); // Add user as dependency so it runs after user is loaded

  // Initialize with a greeting message
  useEffect(() => {
    const initialMessage: Message = {
      id: generateId(),
      sender: "assistant",
      text: showApiKeyPrompt 
        ? "To use the AI assistant with advanced capabilities, please set up your OpenAI API key in the settings. For now, I'll respond with pre-programmed answers to common questions."
        : aiResponses.greeting,
      timestamp: new Date()
    };
    setMessages([initialMessage]);
  }, [showApiKeyPrompt]);

  // Auto scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userInput = input.trim();
    
    // Add user message
    const userMessage: Message = {
      id: generateId(),
      sender: "user",
      text: userInput,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);
    
    try {
      if (openAIStatus?.enabled) {
        // Use OpenAI API
        const response = await fetch('/api/ai/message', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include', // Important for cookie-based auth
          body: JSON.stringify({ message: userInput }),
        });
        
        const data = await response.json();
        
        // Check if we have a valid response
        if (response.ok && data.response) {
          const aiMessage: Message = {
            id: generateId(),
            sender: "assistant",
            text: data.response,
            timestamp: new Date()
          };
          
          setMessages(prev => [...prev, aiMessage]);
        } else if (data.fallback) {
          // Handle fallback mode from the server
          const aiMessage: Message = {
            id: generateId(),
            sender: "assistant",
            text: data.response || "I'm currently running in fallback mode. Please try again later.",
            timestamp: new Date()
          };
          
          setMessages(prev => [...prev, aiMessage]);
        } else {
          // Handle other errors
          throw new Error(data.message || "Failed to get AI response");
        }
      } else {
        // Use predefined responses as fallback
        setTimeout(() => {
          let responseText = aiResponses.default;
          
          // Simple keyword matching for demo purposes
          const lowerInput = userInput.toLowerCase();
          if (lowerInput.includes("productivity") || lowerInput.includes("efficient") || lowerInput.includes("tips")) {
            responseText = aiResponses.productivity;
          } else if (lowerInput.includes("focus") || lowerInput.includes("concentrate") || lowerInput.includes("attention")) {
            responseText = aiResponses.focus;
          } else if (lowerInput.includes("motivate") || lowerInput.includes("motivation") || lowerInput.includes("inspired")) {
            responseText = aiResponses.motivation;
          }
          
          const aiMessage: Message = {
            id: generateId(),
            sender: "assistant",
            text: responseText,
            timestamp: new Date()
          };
          
          setMessages(prev => [...prev, aiMessage]);
        }, 1000);
      }
    } catch (error) {
      console.error("Error in AI response:", error);
      // Add error message
      const errorMessage: Message = {
        id: generateId(),
        sender: "assistant",
        text: "I'm sorry, I encountered an error processing your request. Please try again later.",
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSend();
    }
  };

  if (!user) return null;

  return (
    <div className="flex flex-col min-h-screen pb-20">
      <header className="bg-background sticky top-0 z-10 border-b border-border">
        <div className="flex items-center justify-between p-4">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigate("/")}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex flex-col items-center">
            <h1 className="text-lg font-medium flex items-center">
              <Sparkles className="h-5 w-5 text-primary mr-2" />
              AI Assistant
            </h1>
            {openAIStatus !== null && (
              <div className="text-xs flex items-center mt-1">
                <div className={`w-2 h-2 rounded-full mr-1 ${openAIStatus.enabled ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                <span className="text-muted-foreground">{openAIStatus.enabled ? 'AI Assistant Connected' : 'Using basic mode'}</span>
              </div>
            )}
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => {
              // Reset conversation
              setMessages([{
                id: generateId(),
                sender: "assistant",
                text: showApiKeyPrompt 
                  ? "To use the AI assistant with advanced capabilities, please set up your OpenAI API key in the settings. For now, I'll respond with pre-programmed answers to common questions."
                  : aiResponses.greeting,
                timestamp: new Date()
              }]);
            }}
          >
            <RefreshCw className="h-5 w-5" />
          </Button>
        </div>
      </header>
      
      <main className="flex-1 p-4 overflow-y-auto pb-20">
        {!openAIStatus?.enabled && (
          <div className="bg-primary/10 rounded-lg p-4 mb-4 border border-primary/20">
            <h3 className="text-sm font-semibold flex items-center mb-2">
              <Sparkles className="h-4 w-4 text-primary mr-2" />
              AI Assistant Setup
            </h3>
            <p className="text-xs text-muted-foreground mb-3">
              To enable AI features, please check your Gemini API key configuration.
            </p>
          </div>
        )}
        
        <div className="flex flex-col space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.sender === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`flex max-w-[80%] ${
                  message.sender === "user" ? "flex-row-reverse" : "flex-row"
                }`}
              >
                <div
                  className={`flex items-center justify-center h-8 w-8 rounded-full ${
                    message.sender === "user" 
                      ? "bg-primary text-primary-foreground ml-2" 
                      : "bg-secondary mr-2"
                  }`}
                >
                  {message.sender === "user" ? (
                    <User className="h-4 w-4" />
                  ) : (
                    <Bot className="h-4 w-4" />
                  )}
                </div>
                <Card
                  className={`p-3 ${
                    message.sender === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary"
                  }`}
                >
                  <p className="text-sm whitespace-pre-line">{message.text}</p>
                </Card>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="flex flex-row">
                <div className="flex items-center justify-center h-8 w-8 rounded-full bg-secondary mr-2">
                  <Bot className="h-4 w-4" />
                </div>
                <Card className="p-3 bg-secondary">
                  <div className="flex space-x-1">
                    <div className="h-2 w-2 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                    <div className="h-2 w-2 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    <div className="h-2 w-2 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </Card>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>
      
      <div className="fixed bottom-20 left-0 right-0 p-4 bg-background border-t border-border">
        <div className="flex space-x-2">
          <Input
            placeholder="Ask for productivity tips..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="bg-secondary/30"
          />
          <Button 
            className="bg-primary text-primary-foreground hover:bg-primary/90 p-2"
            onClick={handleSend}
            disabled={!input.trim()}
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
}