import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import BottomNavigation from "@/components/BottomNavigation";
import { 
  ArrowLeft, 
  Trophy, 
  Flame, 
  Clock, 
  Calendar,
  Award,
  LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function ProfilePage() {
  const { user, logoutMutation } = useAuth();
  const [, navigate] = useLocation();

  // Fetch user stats
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/stats"],
  });

  // Fetch user's tasks
  const { data: tasks } = useQuery({
    queryKey: ["/api/tasks"],
  });

  // Calculate completion rate
  const completedTasks = tasks?.filter(task => task.completed).length || 0;
  const totalTasks = tasks?.length || 0;
  const completionRate = totalTasks > 0 
    ? Math.round((completedTasks / totalTasks) * 100) 
    : 0;

  // Format user initials for avatar
  const getInitials = (username: string) => {
    return username.substring(0, 2).toUpperCase();
  };

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        navigate("/auth");
      }
    });
  };

  if (!user) return null;

  return (
    <div className="min-h-screen pb-20">
      <header className="bg-background sticky top-0 z-10 border-b border-border">
        <div className="flex items-center justify-between p-4">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigate("/")}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-medium">Profile</h1>
          <div className="w-9"></div> {/* Spacer for layout balance */}
        </div>
      </header>
      
      <main className="p-4">
        <div className="flex flex-col items-center mb-6">
          <Avatar className="h-20 w-20 mb-3">
            <AvatarFallback className="bg-primary text-primary-foreground text-xl">
              {getInitials(user.username)}
            </AvatarFallback>
          </Avatar>
          <h2 className="text-xl font-semibold">{user.username}</h2>
        </div>
        
        {/* Stats Section */}
        <h3 className="font-medium mb-3">Your Stats</h3>
        <div className="grid grid-cols-2 gap-3 mb-6">
          <Card>
            <CardContent className="p-3 flex flex-col items-center">
              <Trophy className="h-5 w-5 text-primary mb-1" />
              <span className="text-xs text-muted-foreground">Total Points</span>
              {isLoadingStats ? (
                <Skeleton className="h-6 w-16 mt-1" />
              ) : (
                <span className="font-semibold">{stats?.totalPoints || 0}</span>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-3 flex flex-col items-center">
              <Flame className="h-5 w-5 text-primary mb-1" />
              <span className="text-xs text-muted-foreground">Streak</span>
              {isLoadingStats ? (
                <Skeleton className="h-6 w-16 mt-1" />
              ) : (
                <span className="font-semibold">{stats?.streakDays || 0} days</span>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-3 flex flex-col items-center">
              <Clock className="h-5 w-5 text-primary mb-1" />
              <span className="text-xs text-muted-foreground">Focus Time</span>
              {isLoadingStats ? (
                <Skeleton className="h-6 w-16 mt-1" />
              ) : (
                <span className="font-semibold">
                  {Math.floor((stats?.todayFocusTimeMinutes || 0) / 60)}h {(stats?.todayFocusTimeMinutes || 0) % 60}m
                </span>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-3 flex flex-col items-center">
              <Calendar className="h-5 w-5 text-primary mb-1" />
              <span className="text-xs text-muted-foreground">Completion Rate</span>
              <span className="font-semibold">{completionRate}%</span>
            </CardContent>
          </Card>
        </div>
        
        {/* Achievements Section */}
        <h3 className="font-medium mb-3">Achievements</h3>
        <div className="bg-secondary/30 rounded-lg p-4 mb-6">
          <div className="flex items-center mb-4">
            <Award className="h-6 w-6 text-primary mr-3" />
            <div>
              <h4 className="font-medium">Early Bird</h4>
              <p className="text-xs text-muted-foreground">Complete 5 tasks before 9am</p>
            </div>
          </div>
          
          <div className="flex items-center">
            <Award className="h-6 w-6 text-muted-foreground mr-3" />
            <div>
              <h4 className="font-medium text-muted-foreground">Focus Master</h4>
              <p className="text-xs text-muted-foreground">Complete 10 focus sessions of 25+ minutes</p>
            </div>
          </div>
        </div>
        
        {/* Account Actions */}
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button 
              variant="destructive" 
              className="w-full flex items-center"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Log Out
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure you want to log out?</AlertDialogTitle>
              <AlertDialogDescription>
                You'll need to sign in again to access your tasks and focus sessions.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleLogout}>
                Log Out
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </main>
      
      <BottomNavigation />
    </div>
  );
}