import React, { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import FocusTimer from "@/components/FocusTimer";
import { Task } from "@shared/schema";

export default function FocusModePage() {
  const [, navigate] = useLocation();
  const [currentTaskId, setCurrentTaskId] = useState<string>("");

  // Fetch user's tasks for selection
  const { data: tasks, isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  // Fetch user's focus sessions
  const { data: focusSessions } = useQuery({
    queryKey: ["/api/focus-sessions/user"],
  });

  // Fetch user stats
  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
  });

  // Filter to get only incomplete tasks
  const incompleteTasks = tasks?.filter(task => !task.completed) || [];

  // Calculate stats
  const totalFocusTime = focusSessions?.reduce((acc, session) => {
    return acc + (session.duration || 0);
  }, 0) || 0;

  const totalFocusHours = Math.floor(totalFocusTime / 60);
  const totalFocusMinutes = totalFocusTime % 60;

  const completedTasks = tasks?.filter(task => task.completed).length || 0;
  const totalTasks = tasks?.length || 0;

  // Find the selected task object
  const selectedTask = incompleteTasks.find(
    task => task.id.toString() === currentTaskId
  );

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 pt-5 pb-2 flex items-center justify-between">
        <Button 
          variant="ghost" 
          size="icon" 
          className="rounded-full"
          onClick={() => navigate("/")}
        >
          <X className="h-5 w-5 text-muted-foreground" />
        </Button>
        <h1 className="font-semibold">Focus Session</h1>
        <div className="w-8 h-8"></div> {/* Empty div for flex alignment */}
      </header>
      
      <main className="flex-1 flex flex-col items-center justify-center p-5">
        {/* Task Selection */}
        <div className="w-full mb-10">
          <label className="block text-sm text-muted-foreground mb-2">Current Task</label>
          <Select 
            value={currentTaskId} 
            onValueChange={setCurrentTaskId}
            disabled={isLoading}
          >
            <SelectTrigger className="w-full bg-secondary/30">
              <SelectValue placeholder="Select a task (optional)" />
            </SelectTrigger>
            <SelectContent>
              {incompleteTasks.map(task => (
                <SelectItem key={task.id} value={task.id.toString()}>
                  {task.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Timer Display */}
        <FocusTimer 
          task={selectedTask} 
          initialMinutes={25}
          className="mb-10"
        />
        
        {/* Session Stats */}
        <Card className="w-full">
          <CardContent className="pt-4">
            <h3 className="text-sm font-medium mb-3">Session Statistics</h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-muted-foreground text-xs">Total Focus Time</p>
                <p className="text-lg font-semibold">
                  {totalFocusHours}h {totalFocusMinutes}m
                </p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Tasks Completed</p>
                <p className="text-lg font-semibold">
                  {completedTasks} / {totalTasks}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Points Earned</p>
                <p className="text-lg font-semibold">{stats?.totalPoints || 0}</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Current Streak</p>
                <p className="text-lg font-semibold">{stats?.streakDays || 0} days</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
