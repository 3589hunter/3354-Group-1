import React from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { z } from "zod";
import { insertTaskSchema } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Create a form schema based on our task schema
const taskFormSchema = z.object({
  title: z.string().min(1, "Title is required"),
  category: z.enum(["Study", "Work", "Personal", "Health"]),
  dueDate: z.string().min(1, "Due date is required"),
  dueTime: z.string().min(1, "Due time is required"),
  expectedDuration: z.number().min(1, "Duration is required"),
  notes: z.string().optional().nullable(),
});

type TaskFormValues = z.infer<typeof taskFormSchema>;

export default function NewTaskPage() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  
  // Setup form
  const form = useForm<TaskFormValues>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      title: "",
      category: "Study",
      dueDate: new Date().toISOString().split("T")[0], // Today's date in YYYY-MM-DD format
      dueTime: "12:00",
      expectedDuration: 30,
      notes: "",
    },
  });

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: async (data: TaskFormValues) => {
      const res = await apiRequest("POST", "/api/tasks", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Task created",
        description: "Your task has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/upcoming"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/today"] });
      navigate("/");
    },
    onError: (error: Error) => {
      toast({
        title: "Could not create task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: TaskFormValues) {
    try {
      // Convert separate date and time fields to a single ISO string
      const dateTime = new Date(`${data.dueDate}T${data.dueTime}`);
      
      // Create the task data with transformed date
      const taskData = {
        title: data.title,
        category: data.category,
        dueDate: dateTime.toISOString(),  // Send as ISO string for consistency
        expectedDuration: data.expectedDuration,
        notes: data.notes,
      };
      
      console.log("Sending task data:", taskData);
      createTaskMutation.mutate(taskData);
    } catch (error) {
      console.error("Error creating task:", error);
      toast({
        title: "Error creating task",
        description: "There was a problem with the date format. Please try again.",
        variant: "destructive",
      });
    }
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 pt-5 pb-3 flex items-center justify-between border-b border-border">
        <Button 
          variant="ghost" 
          onClick={() => navigate("/")}
        >
          Cancel
        </Button>
        <h1 className="font-semibold">New Task</h1>
        <Button 
          variant="default" 
          className="bg-primary text-primary-foreground hover:bg-primary/90"
          onClick={form.handleSubmit(onSubmit)}
          disabled={createTaskMutation.isPending}
        >
          Save
        </Button>
      </header>
      
      <main className="flex-1 p-4">
        <Form {...form}>
          <form className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Task Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="What do you need to do?"
                      className="bg-secondary/30"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="bg-secondary/30">
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Study">Study</SelectItem>
                      <SelectItem value="Work">Work</SelectItem>
                      <SelectItem value="Personal">Personal</SelectItem>
                      <SelectItem value="Health">Health</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-2">
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due Date</FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        className="bg-secondary/30"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="dueTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due Time</FormLabel>
                    <FormControl>
                      <Input 
                        type="time" 
                        className="bg-secondary/30"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="expectedDuration"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Expected Duration (mins)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min="1"
                      className="bg-secondary/30"
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Add any additional details..."
                      className="bg-secondary/30 min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </form>
        </Form>
      </main>
    </div>
  );
}
