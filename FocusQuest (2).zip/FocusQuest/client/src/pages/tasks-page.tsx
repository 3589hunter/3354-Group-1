import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import TaskList from "@/components/TaskList";
import BottomNavigation from "@/components/BottomNavigation";
import { ArrowLeft, ListFilter, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Task } from "@shared/schema";

export default function TasksPage() {
  const [, navigate] = useLocation();
  const [filter, setFilter] = useState<string>("all");
  
  // Fetch all tasks
  const { data: allTasks, isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });
  
  // Fetch today's tasks
  const { data: todayTasks, isLoading: isLoadingToday } = useQuery<Task[]>({
    queryKey: ["/api/tasks/today"],
  });
  
  // Fetch upcoming tasks
  const { data: upcomingTasks, isLoading: isLoadingUpcoming } = useQuery<Task[]>({
    queryKey: ["/api/tasks/upcoming"],
  });
  
  // Filter tasks based on selection
  const filteredTasks = () => {
    if (!allTasks) return [];
    
    switch (filter) {
      case "today":
        return todayTasks || [];
      case "upcoming":
        return upcomingTasks || [];
      case "completed":
        return allTasks.filter(task => task.completed);
      case "incomplete":
        return allTasks.filter(task => !task.completed);
      case "all":
      default:
        return allTasks;
    }
  };
  
  const tasks = filteredTasks();
  
  return (
    <div className="min-h-screen pb-20">
      <header className="bg-background sticky top-0 z-10 border-b border-border">
        <div className="flex items-center justify-between p-4">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigate("/")}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-medium">Tasks</h1>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigate("/new-task")}
          >
            <Plus className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="px-4 pb-3 flex items-center">
          <div className="flex items-center gap-2">
            <ListFilter className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Filter:</span>
          </div>
          <Select 
            value={filter} 
            onValueChange={setFilter}
          >
            <SelectTrigger className="ml-2 h-8 w-40 bg-secondary/30">
              <SelectValue placeholder="Filter tasks" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Tasks</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="upcoming">Upcoming</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="incomplete">Incomplete</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </header>
      
      <main className="p-4">
        {isLoading ? (
          // Loading state
          <div className="space-y-4">
            <Skeleton className="h-16 w-full rounded-lg" />
            <Skeleton className="h-16 w-full rounded-lg" />
            <Skeleton className="h-16 w-full rounded-lg" />
            <Skeleton className="h-16 w-full rounded-lg" />
          </div>
        ) : tasks.length > 0 ? (
          // Tasks list
          <div className="space-y-2">
            {tasks.map((task) => (
              <div 
                key={task.id}
                className="bg-secondary/30 rounded-lg p-3 cursor-pointer"
                onClick={() => navigate(`/task/${task.id}`)}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className={`font-medium ${task.completed ? 'line-through text-muted-foreground' : ''}`}>
                      {task.title}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      {task.category} • {task.expectedDuration} min
                    </p>
                  </div>
                  {task.completed && (
                    <span className="bg-primary/20 text-primary text-xs px-2 py-1 rounded-full">
                      +{task.pointsAwarded || 0} pts
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          // Empty state
          <div className="text-center py-8">
            <p className="text-muted-foreground mb-4">No tasks found</p>
            <Button onClick={() => navigate("/new-task")}>
              Create New Task
            </Button>
          </div>
        )}
      </main>
      
      <BottomNavigation />
    </div>
  );
}