import React, { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import {
  ArrowLeft,
  MoreVertical,
  Clock,
  Pencil,
  Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Task, FocusSession } from "@shared/schema";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function TaskDetailsPage() {
  const [, params] = useRoute<{ id: string }>("/task/:id");
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  
  // Check if we're in edit mode from query params
  const editMode = location.includes("?edit=true");
  
  // Get task ID from params
  const taskId = params?.id ? parseInt(params.id) : 0;

  // Fetch task details
  const { data: task, isLoading: isLoadingTask } = useQuery<Task>({
    queryKey: [`/api/tasks/${taskId}`],
    enabled: !!taskId,
  });

  // Fetch focus sessions for this task
  const { data: focusSessions, isLoading: isLoadingSessions } = useQuery<FocusSession[]>({
    queryKey: [`/api/focus-sessions/task/${taskId}`],
    enabled: !!taskId,
  });

  // Delete task mutation
  const deleteTaskMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/tasks/${taskId}`);
    },
    onSuccess: () => {
      toast({
        title: "Task deleted",
        description: "The task has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/upcoming"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/today"] });
      navigate("/");
    },
    onError: (error: Error) => {
      toast({
        title: "Could not delete task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Complete task mutation
  const completeTaskMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/tasks/${taskId}/complete`);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Task completed",
        description: `You earned ${task?.expectedDuration} points!`,
      });
      queryClient.invalidateQueries({ queryKey: [`/api/tasks/${taskId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/upcoming"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/today"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Could not complete task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCompleteTask = () => {
    completeTaskMutation.mutate();
  };

  const handleEditTask = () => {
    navigate(`/task/${taskId}?edit=true`);
  };

  const handleDeleteTask = () => {
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    deleteTaskMutation.mutate();
    setShowDeleteDialog(false);
  };

  const handleStartFocusSession = () => {
    navigate(`/focus?taskId=${taskId}`);
  };

  const formatDateTime = (date: Date | string) => {
    return format(new Date(date), "MMM d, yyyy h:mm a");
  };

  const formatFocusSessionDate = (date: Date | string) => {
    return format(new Date(date), "MMM d, h:mm a");
  };

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 pt-5 pb-3 flex items-center justify-between border-b border-border">
        <Button 
          variant="ghost"
          size="icon"
          onClick={() => navigate("/")}
        >
          <ArrowLeft className="h-5 w-5 text-muted-foreground" />
        </Button>
        <h1 className="font-semibold">Task Details</h1>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="ghost"
              size="icon"
            >
              <MoreVertical className="h-5 w-5 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {!task?.completed && (
              <DropdownMenuItem onClick={handleEditTask}>
                Edit task
              </DropdownMenuItem>
            )}
            {!task?.completed && (
              <DropdownMenuItem onClick={handleCompleteTask}>
                Mark as completed
              </DropdownMenuItem>
            )}
            <DropdownMenuItem 
              className="text-destructive focus:text-destructive"
              onClick={handleDeleteTask}
            >
              Delete task
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </header>
      
      <main className="flex-1 p-4">
        {isLoadingTask ? (
          <div className="space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <div className="grid grid-cols-2 gap-3">
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
            </div>
            <Skeleton className="h-32 w-full" />
          </div>
        ) : task ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">{task.title}</h2>
              <Button 
                variant="ghost"
                size="icon"
                className={task.completed 
                  ? "w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center" 
                  : "w-6 h-6 rounded-full border-2 border-primary"
                }
                onClick={handleCompleteTask}
                disabled={task.completed || completeTaskMutation.isPending}
              >
                {task.completed && <Check className="h-3 w-3" />}
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-secondary/30 rounded-lg p-3">
                <span className="text-muted-foreground text-xs">Due Date</span>
                <p className="font-medium mt-1">
                  {format(new Date(task.dueDate), "MMM d, yyyy")}
                </p>
              </div>
              
              <div className="bg-secondary/30 rounded-lg p-3">
                <span className="text-muted-foreground text-xs">Due Time</span>
                <p className="font-medium mt-1">
                  {format(new Date(task.dueDate), "h:mm a")}
                </p>
              </div>
              
              <div className="bg-secondary/30 rounded-lg p-3">
                <span className="text-muted-foreground text-xs">Duration</span>
                <p className="font-medium mt-1">{task.expectedDuration} minutes</p>
              </div>
              
              <div className="bg-secondary/30 rounded-lg p-3">
                <span className="text-muted-foreground text-xs">Points</span>
                <p className="font-medium mt-1">
                  {task.completed 
                    ? `${task.pointsAwarded} points earned` 
                    : `${task.expectedDuration} points possible`
                  }
                </p>
              </div>
            </div>
            
            <div className="bg-secondary/30 rounded-lg p-3">
              <span className="text-muted-foreground text-xs">Category</span>
              <p className="font-medium mt-1">{task.category}</p>
            </div>
            
            {task.notes && (
              <div className="bg-secondary/30 rounded-lg p-3">
                <span className="text-muted-foreground text-xs">Notes</span>
                <p className="text-sm mt-1">{task.notes}</p>
              </div>
            )}
            
            <div className="bg-secondary/30 rounded-lg p-3">
              <span className="text-muted-foreground text-xs">Focus Sessions</span>
              {isLoadingSessions ? (
                <div className="space-y-2 mt-2">
                  <Skeleton className="h-6 w-full" />
                  <Skeleton className="h-6 w-full" />
                </div>
              ) : focusSessions && focusSessions.length > 0 ? (
                <div className="space-y-2 mt-2">
                  {focusSessions.map((session) => (
                    <div key={session.id} className="flex justify-between items-center text-sm">
                      <span>{formatFocusSessionDate(session.startTime)}</span>
                      <span>{session.duration} minutes</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm mt-2 text-muted-foreground">No focus sessions yet</p>
              )}
            </div>
            
            {!task.completed && (
              <div className="flex space-x-2 mt-6">
                <Button 
                  className="flex-1"
                  onClick={handleStartFocusSession}
                >
                  Start Focus Session
                </Button>
                <Button 
                  variant="outline"
                  size="icon"
                  className="rounded-lg"
                  onClick={handleEditTask}
                >
                  <Pencil className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-muted-foreground">Task not found</p>
          </div>
        )}
      </main>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Task</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this task? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowDeleteDialog(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={confirmDelete}
              disabled={deleteTaskMutation.isPending}
            >
              {deleteTaskMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
