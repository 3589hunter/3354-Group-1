import { users, tasks, focusSessions, type User, type InsertUser, type Task, type InsertTask, type FocusSession, type InsertFocusSession } from "@shared/schema";
import { db } from "./db";
import { eq, and, lt, gte, desc, isNull, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: number, pointsToAdd: number): Promise<User>;
  updateUserStreak(userId: number): Promise<User>;
  
  // Task operations
  getTaskById(taskId: number): Promise<Task | undefined>;
  getTasksByUserId(userId: number): Promise<Task[]>;
  getUpcomingTasks(userId: number): Promise<Task[]>;
  getTodaysTasks(userId: number): Promise<Task[]>;
  createTask(task: InsertTask & { userId: number }): Promise<Task>;
  updateTask(taskId: number, updates: Partial<Task>): Promise<Task | undefined>;
  completeTask(taskId: number, completionTime: Date): Promise<Task | undefined>;
  deleteTask(taskId: number): Promise<boolean>;
  
  // Focus session operations
  createFocusSession(session: InsertFocusSession): Promise<FocusSession>;
  endFocusSession(sessionId: number, endTime: Date, duration: number, pointsEarned: number): Promise<FocusSession | undefined>;
  getFocusSessionsByTask(taskId: number): Promise<FocusSession[]>;
  getFocusSessionsByUser(userId: number): Promise<FocusSession[]>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
      tableName: 'session'
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async updateUserPoints(userId: number, pointsToAdd: number): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({
        totalPoints: sql`${users.totalPoints} + ${pointsToAdd}`,
        lastActive: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return updatedUser;
  }
  
  async updateUserStreak(userId: number): Promise<User> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    
    // Check if last active was yesterday or today
    const lastActive = user?.lastActive ? new Date(user.lastActive) : new Date(0);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    const lastActiveDay = new Date(lastActive.getFullYear(), lastActive.getMonth(), lastActive.getDate());
    const yesterdayDay = new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate());
    
    // If last active was yesterday, increment streak
    // If it was earlier than yesterday, reset streak to 1
    // If it was today, keep the streak
    let streakDays = user?.streakDays || 0;
    if (lastActiveDay.getTime() === yesterdayDay.getTime()) {
      streakDays += 1;
    } else if (lastActiveDay.getTime() < yesterdayDay.getTime()) {
      streakDays = 1;
    }
    
    const [updatedUser] = await db
      .update(users)
      .set({
        streakDays,
        lastActive: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  // Task operations
  async getTaskById(taskId: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, taskId));
    return task;
  }

  async getTasksByUserId(userId: number): Promise<Task[]> {
    return db
      .select()
      .from(tasks)
      .where(eq(tasks.userId, userId))
      .orderBy(tasks.dueDate);
  }

  async getUpcomingTasks(userId: number): Promise<Task[]> {
    const now = new Date();
    return db
      .select()
      .from(tasks)
      .where(
        and(
          eq(tasks.userId, userId),
          gte(tasks.dueDate, now),
          eq(tasks.completed, false)
        )
      )
      .orderBy(tasks.dueDate)
      .limit(7);
  }

  async getTodaysTasks(userId: number): Promise<Task[]> {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    return db
      .select()
      .from(tasks)
      .where(
        and(
          eq(tasks.userId, userId),
          gte(tasks.dueDate, today),
          lt(tasks.dueDate, tomorrow)
        )
      )
      .orderBy(tasks.dueDate);
  }

  async createTask(task: InsertTask & { userId: number }): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values(task)
      .returning();
    return newTask;
  }

  async updateTask(taskId: number, updates: Partial<Task>): Promise<Task | undefined> {
    const [updatedTask] = await db
      .update(tasks)
      .set(updates)
      .where(eq(tasks.id, taskId))
      .returning();
    return updatedTask;
  }

  async completeTask(taskId: number, completionTime: Date): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, taskId));
    
    if (!task) return undefined;
    
    // Calculate points based on expected duration
    const pointsAwarded = task.expectedDuration;
    
    const [completedTask] = await db
      .update(tasks)
      .set({
        completed: true,
        completedAt: completionTime,
        pointsAwarded
      })
      .where(eq(tasks.id, taskId))
      .returning();
      
    // Also update user points
    if (completedTask) {
      await this.updateUserPoints(completedTask.userId, pointsAwarded);
    }
    
    return completedTask;
  }

  async deleteTask(taskId: number): Promise<boolean> {
    const result = await db
      .delete(tasks)
      .where(eq(tasks.id, taskId));
      
    return result.rowCount > 0;
  }

  // Focus session operations
  async createFocusSession(session: InsertFocusSession): Promise<FocusSession> {
    const [newSession] = await db
      .insert(focusSessions)
      .values(session)
      .returning();
    return newSession;
  }

  async endFocusSession(sessionId: number, endTime: Date, duration: number, pointsEarned: number): Promise<FocusSession | undefined> {
    const [session] = await db
      .update(focusSessions)
      .set({
        endTime,
        duration,
        pointsEarned
      })
      .where(eq(focusSessions.id, sessionId))
      .returning();
      
    if (session) {
      // Update user points
      await this.updateUserPoints(session.userId, pointsEarned);
      await this.updateUserStreak(session.userId);
    }
    
    return session;
  }

  async getFocusSessionsByTask(taskId: number): Promise<FocusSession[]> {
    return db
      .select()
      .from(focusSessions)
      .where(eq(focusSessions.taskId, taskId))
      .orderBy(desc(focusSessions.startTime));
  }

  async getFocusSessionsByUser(userId: number): Promise<FocusSession[]> {
    return db
      .select()
      .from(focusSessions)
      .where(eq(focusSessions.userId, userId))
      .orderBy(desc(focusSessions.startTime));
  }
}

export const storage = new DatabaseStorage();
