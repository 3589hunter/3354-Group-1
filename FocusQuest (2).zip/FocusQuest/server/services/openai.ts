import { GoogleGenerativeAI } from '@google/generative-ai';

function getGeminiClient() {
  if (!process.env.GEMINI_API_KEY) {
    console.log("GEMINI_API_KEY environment variable is not set");
    throw new Error("Gemini API key is not configured");
  }

  return new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
}

function getModel() {
    const client = getGeminiClient();
    return client.getGenerativeModel({ model: 'gemini-1.5-flash-latest' });
}

async function testGeminiAPI() {
    const model = getModel();
    const prompt = 'Hi there!';
    const result = await model.generateContent(prompt);
    return result.response.text();
}

export async function checkAIApiKey(): Promise<{ success: boolean; error?: string }> {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.log("No Gemini API key found in environment variables");
      return {
        success: false,
        error: "Missing API key"
      };
    }

    // Create a client and test it
    const model = getModel();
    // Test with a simple prompt
    const result = await model.generateContent('Test');
    return { success: true };
  } catch (error: any) {
    console.error("Gemini API key verification failed:", error);
    return { success: false, error: "API key verification failed" };
  }
}

export async function getAIResponse(message: string): Promise<string> {
  try {
    const model = getModel();

    const prompt = `You are a helpful AI assistant for FocusQuest, a productivity app. Your expertise includes:

1. Productivity techniques: Pomodoro, time blocking, task batching, etc.
2. Focus improvement: Deep work, flow state, distraction management
3. Task management: Prioritization, planning, breaking down complex tasks
4. Motivation: Building habits, overcoming procrastination, setting meaningful goals
5. Work-life balance: Preventing burnout, energy management

Keep responses concise (max 4-5 paragraphs) and practical with actionable advice. Use a friendly, encouraging tone.

User message: ${message}`;

    const result = await model.generateContent(prompt);
    const response = result.response;
    return response.text() || "I'm having trouble generating a response right now.";
  } catch (error: any) {
    console.error("Error getting AI response:", error);
    return "Sorry, I encountered an error while processing your request. Please try again later.";
  }
}