import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertTaskSchema } from "@shared/schema";
import { z } from "zod";
import { checkOpenAIApiKey, getAIResponse, checkAIApiKey } from "./services/openai";

// Middleware to check if user is authenticated
const isAuthenticated = (req: any, res: any, next: any) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Task routes
  app.get("/api/tasks", isAuthenticated, async (req, res, next) => {
    try {
      const tasks = await storage.getTasksByUserId(req.user!.id);
      res.json(tasks);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/tasks/upcoming", isAuthenticated, async (req, res, next) => {
    try {
      const tasks = await storage.getUpcomingTasks(req.user!.id);
      res.json(tasks);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/tasks/today", isAuthenticated, async (req, res, next) => {
    try {
      const tasks = await storage.getTodaysTasks(req.user!.id);
      res.json(tasks);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/tasks/:id", isAuthenticated, async (req, res, next) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTaskById(taskId);

      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Security check - only allow access to user's own tasks
      if (task.userId !== req.user!.id) {
        return res.status(403).json({ message: "Forbidden" });
      }

      res.json(task);
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/tasks", isAuthenticated, async (req, res, next) => {
    try {
      console.log("Received task data:", req.body);

      // Handle the date format issue by converting to ISO string if it's a Date object
      let taskData = { ...req.body };

      // Convert date string to ISO format if needed
      if (typeof taskData.dueDate === 'string') {
        try {
          const dateObj = new Date(taskData.dueDate);
          taskData.dueDate = dateObj;
        } catch (e) {
          console.error("Date parsing error:", e);
        }
      }

      const parsedData = insertTaskSchema.parse(taskData);

      const newTask = await storage.createTask({
        ...parsedData,
        userId: req.user!.id,
      });

      res.status(201).json(newTask);
    } catch (err) {
      if (err instanceof z.ZodError) {
        console.error("Validation error:", err.errors);
        return res.status(400).json({ errors: err.errors });
      }
      console.error("Server error:", err);
      next(err);
    }
  });

  app.put("/api/tasks/:id", isAuthenticated, async (req, res, next) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTaskById(taskId);

      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Security check - only allow update of user's own tasks
      if (task.userId !== req.user!.id) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const updates = req.body;
      const updatedTask = await storage.updateTask(taskId, updates);
      res.json(updatedTask);
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/tasks/:id/complete", isAuthenticated, async (req, res, next) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTaskById(taskId);

      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Security check - only allow completion of user's own tasks
      if (task.userId !== req.user!.id) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const completedTask = await storage.completeTask(taskId, new Date());
      res.json(completedTask);
    } catch (err) {
      next(err);
    }
  });

  app.delete("/api/tasks/:id", isAuthenticated, async (req, res, next) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTaskById(taskId);

      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Security check - only allow deletion of user's own tasks
      if (task.userId !== req.user!.id) {
        return res.status(403).json({ message: "Forbidden" });
      }

      await storage.deleteTask(taskId);
      res.status(204).end();
    } catch (err) {
      next(err);
    }
  });

  // Focus session routes
  app.post("/api/focus-sessions", isAuthenticated, async (req, res, next) => {
    try {
      const { taskId } = req.body;

      // If taskId is provided, verify it belongs to the user
      if (taskId) {
        const task = await storage.getTaskById(parseInt(taskId));
        if (!task) {
          return res.status(404).json({ message: "Task not found" });
        }

        if (task.userId !== req.user!.id) {
          return res.status(403).json({ message: "Forbidden" });
        }
      }

      const focusSession = await storage.createFocusSession({
        userId: req.user!.id,
        taskId: taskId ? parseInt(taskId) : undefined,
        startTime: new Date(),
      });

      res.status(201).json(focusSession);
    } catch (err) {
      next(err);
    }
  });

  app.put("/api/focus-sessions/:id/end", isAuthenticated, async (req, res, next) => {
    try {
      const sessionId = parseInt(req.params.id);
      const { duration, pointsEarned } = req.body;

      // Security check would go here, but we'd need to add a query to get a focus session by ID
      // For now, we'll just assume that the database constraints and our authorization will prevent access to other users' sessions

      const endTime = new Date();
      const updatedSession = await storage.endFocusSession(
        sessionId, 
        endTime, 
        duration, 
        pointsEarned
      );

      if (!updatedSession) {
        return res.status(404).json({ message: "Focus session not found" });
      }

      res.json(updatedSession);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/focus-sessions/task/:taskId", isAuthenticated, async (req, res, next) => {
    try {
      const taskId = parseInt(req.params.taskId);
      const task = await storage.getTaskById(taskId);

      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Security check - only allow access to sessions for user's own tasks
      if (task.userId !== req.user!.id) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const sessions = await storage.getFocusSessionsByTask(taskId);
      res.json(sessions);
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/focus-sessions/user", isAuthenticated, async (req, res, next) => {
    try {
      const sessions = await storage.getFocusSessionsByUser(req.user!.id);
      res.json(sessions);
    } catch (err) {
      next(err);
    }
  });

  // Stats routes
  app.get("/api/stats", isAuthenticated, async (req, res, next) => {
    try {
      const user = await storage.getUser(req.user!.id);
      const focusSessions = await storage.getFocusSessionsByUser(req.user!.id);

      // Calculate total focus time today
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const todayFocusSessions = focusSessions.filter(session => {
        const sessionDate = new Date(session.startTime);
        return sessionDate >= today && session.duration !== null;
      });

      const todayFocusTimeMinutes = todayFocusSessions.reduce((acc, session) => {
        return acc + (session.duration || 0);
      }, 0);

      // Calculate points earned today
      const todayPointsEarned = todayFocusSessions.reduce((acc, session) => {
        return acc + (session.pointsEarned || 0);
      }, 0);

      res.json({
        totalPoints: user?.totalPoints || 0,
        streakDays: user?.streakDays || 0,
        todayFocusTimeMinutes,
        todayPointsEarned
      });
    } catch (err) {
      next(err);
    }
  });

  // AI assistant routes
  app.get("/api/ai/status", isAuthenticated, async (req, res, next) => {
    try {
      const isValid = await checkAIApiKey();
      console.log("AI API key check result:", isValid);
      res.json({ 
        enabled: isValid,
        message: isValid 
          ? "AI integration is working properly" 
          : "AI API key is not set or is invalid"
      });
    } catch (err) {
      console.error("Error checking AI API key status:", err);
      next(err);
    }
  });

  // This is just a placeholder in a real app 
  // In a production environment, you'd use a more secure method to store API keys
  app.post("/api/ai/setup-key", isAuthenticated, async (req, res, next) => {
    try {
      const { apiKey } = req.body;

      if (!apiKey) {
        return res.status(400).json({ message: "API key is required" });
      }

      // In a real app, you would securely store this API key
      // For this demo, we'll just return a success message
      // The actual key is stored as an environment variable

      res.json({ 
        success: true, 
        message: "API key setup successful" 
      });
    } catch (err) {
      console.error("Error setting up AI API key:", err);
      next(err);
    }
  });

  app.post("/api/ai/message", isAuthenticated, async (req, res, next) => {
    try {
      const { message } = req.body;

      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      // Check if OpenAI API is configured
      const isValid = await checkAIApiKey();
      if (!isValid) {
        return res.status(503).json({ 
          message: "AI API is not configured properly. Please check your API key.",
          fallback: true,
          response: "I'm currently running in fallback mode. To access my full capabilities, please set up your AI API key."
        });
      }

      const response = await getAIResponse(message);

      // Check if the response indicates an error condition
      if (response.includes("I'm currently experiencing high demand") || 
          response.includes("I'm having trouble accessing my AI")) {
        res.json({ 
          response,
          fallback: true 
        });
      } else {
        res.json({ response });
      }
    } catch (err) {
      console.error("Error in AI message endpoint:", err);
      res.status(500).json({ 
        response: "I'm sorry, I encountered an error processing your request. Please try again later.",
        fallback: true,
        message: err.message || "An unexpected error occurred" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}